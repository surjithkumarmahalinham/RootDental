<?php include_once('includes/header.php') ?>
<div id="header-subpage" class="outer news-sub">
        <div class="pagetitle">Gallery<span>&nbsp;</span></div>
        <img src="css/imgs/pen.png" alt="Pen" class="pen" />
        <img src="css/imgs/news.jpg" alt="Keyboard" class="bg" />
        <div class="shape"></div>
    </div>
    <div class="_content2 outer clearafter withtootbrush">
        <div class="clear"></div>

        <div id="peakin" class="outer">
            <div class="oc-gallery clearafter">
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(1).jpg" style="background-image: url('img/gaallery/root-dental%20(1).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(2).jpg" style="background-image: url('img/gaallery/root-dental%20(2).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(3).jpg" style="background-image: url('img/gaallery/root-dental%20(3).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(4).jpg" style="background-image: url('img/gaallery/root-dental%20(4).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(5).jpg" style="background-image: url('img/gaallery/root-dental%20(5).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(6).jpg" style="background-image: url('img/gaallery/root-dental%20(6).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(7).jpg" style="background-image: url('img/gaallery/root-dental%20(7).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(8).jpg" style="background-image: url('img/gaallery/root-dental%20(8).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(9).jpg" style="background-image: url('img/gaallery/root-dental%20(9).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(10).jpg" style="background-image: url('img/gaallery/root-dental%20(10).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(11).jpg" style="background-image: url('img/gaallery/root-dental%20(11).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(12).jpg" style="background-image: url('img/gaallery/root-dental%20(12).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(13).jpg" style="background-image: url('img/gaallery/root-dental%20(13).jpg');"><span><i class="icon-zoomin"></i></span></a>
                <a class="oc-item transition222" rel="ocgallery" href="img/gaallery/root-dental%20(14).jpg" style="background-image: url('img/gaallery/root-dental%20(14).jpg');"><span><i class="icon-zoomin"></i></span></a>
            </div>
        </div>

    </div>
   <?php include_once('includes/footer.php') ?>